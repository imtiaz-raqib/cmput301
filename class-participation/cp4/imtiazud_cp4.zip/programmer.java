public class Programmer extends Employee {

    public Programmer(String name) {
        super(name);
    }
}
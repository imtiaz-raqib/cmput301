public abstract class Employee {
    private name;

    public Employee(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
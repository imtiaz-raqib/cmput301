public class Artist extends Employee {

    public Artist(String name) {
        super(name);
    }
}